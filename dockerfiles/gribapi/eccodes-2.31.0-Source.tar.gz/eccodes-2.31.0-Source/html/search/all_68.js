var searchData=
[
  ['handling_20coded_20messages',['Handling coded messages',['../group__handling__coded__messages.html',1,'']]]
];
